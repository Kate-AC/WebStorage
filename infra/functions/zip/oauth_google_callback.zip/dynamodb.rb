require "aws-sdk"
require "env"

class Dynamodb
  def getCredentials
    Aws::Credentials.new(
      env[:dynamodb_access_key_id],
      env[:dynamodb_secret_access_key]
    )
  end

  def getClient
    Aws::DynamoDB::Client.new(
      endpoint: env[:dynamodb_endpoint],
      region: env[:region],
      credentials: getCredentials,
      stub_responses: false
    )
  end
end

