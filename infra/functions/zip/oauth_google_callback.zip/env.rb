def env
  {
    session_name: "dev-webstorage-session",
    region: "northeast-1",
    s3_access_key: "minio_access_key",
    s3_secret_key: "minio_secret_key",
    s3_endpoint: "http://minio:9000",
    s3_bucket_name: "files",
    dynamodb_access_key_id: "dynamodb_access_key_id",
    dynamodb_secret_access_key: "dynamodb_secret_access_key",
    dynamodb_endpoint: "http://dynamodb:8000"
  }
end

